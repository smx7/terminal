#ifndef THREADPOOL_H_
#define THREADPOOL_H_

#include<iostream>
#include<queue>
#include<pthread.h>

#include"log.h"
#include"condition.h"

#define THREAD_INIT_NUM 5
#define MAX_THREAD_NUM 8
#define MAX_WAIT_TIME 600

typedef int(*handler_t)(int,int*);

class Task
{
    public:
        int sock;
        int* master;
        handler_t handler;
        
    public:
        Task():sock(-1),master(NULL),handler(NULL)
        {
        }

        void SetTask(int _sock,int& master,handler_t _handler);
        void Run();
};

class ThreadPool
{
    private:

        Condition mc;//mutex and cond
        std::queue<Task> task_queue;
        int max_thread_num;
        int thread_total_num;
        int thread_idle_num;
        int wait_seconds;
        volatile bool is_quit;

    public:
        ThreadPool();

        void PushTask(Task &_t);
        void PopTask(Task &_t);
        //void Stop();
        //void ThreadIdle();
        static void* ThreadRoutine(void* arg);
        void InitThreadPool();
};


#endif