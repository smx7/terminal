#ifndef HANDLER_H_
#define HANDLER_H_
#include"server.h"
#include<signal.h>

class PseudoTerminal
{
    public:
        static int handler(int _sock,int* master);
        static int OpenPseudoTerminal(int* master,int& slave);
        static void WaitForChild(int signo);
        static int Communication(int inFd,int* outFd);
};

#endif