#include"server.h"

int TerminalServer::SetNonBlock(int fd)
{
    int ret = fcntl(fd, F_GETFL);
	if (ret < 0)
	{
		LOG(ERROR, "fcntl error");
		return FAILED;
	}

	fcntl(fd, F_SETFL, ret | O_NONBLOCK);
    return SUCCESS;
}

int TerminalServer::InitServer()
{
    do
    {
        listen_sockfd = socket(AF_INET,SOCK_STREAM,0);
        if(listen_sockfd < 0)
        {
            LOG(ERROR,"create socket fd error");
            return FAILED;
        }

        LOG(DEBUG,"create socket fd success");

        int opt = 1;
		setsockopt(listen_sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

		struct sockaddr_in local_addr;
		local_addr.sin_family = AF_INET;
		local_addr.sin_port = htons(port);
		local_addr.sin_addr.s_addr = INADDR_ANY;

        if (bind(listen_sockfd, (struct sockaddr*)&local_addr, sizeof(local_addr)) < 0)
		{
			LOG(ERROR, "bind sockfd error");
			return FAILED;
		}

        LOG(DEBUG,"bind sockfd success");

        if (listen(listen_sockfd,MAX_LISTEN_FD) < 0)
        {
            LOG(ERROR,"listen sockfd error");
            return FAILED;
        }

        LOG(DEBUG,"listen sockfd success");

        epoll_fd = epoll_create(MAX_EPOLL_CREATE_FD);
        if (epoll_fd < 0)
        {
            LOG(ERROR,"epoll create error");
            return FAILED;
        }

        LOG(DEBUG,"epoll create success");

        //int iRet = SetNonBlock(listen_sockfd);
        //if(iRet != SUCCESS)
        //{
            //LOG(ERROR,"set nonblock error");
            //return FAILED;
        //}

        LOG(DEBUG,"set nonblock success");

        struct epoll_event event;
		event.data.fd = listen_sockfd;
		event.events = EPOLLIN;

        if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, listen_sockfd, &event) < 0)
		{
			LOG(ERROR, "epoll ctl listen fd error");
			return FAILED;
		}

        LOG(DEBUG,"epoll ctl listen fd success");

        pool.InitThreadPool();
        LOG(INFO,"init server done");
    }while(false);

    return SUCCESS;
}

void TerminalServer::StartServer()
{
    do
    {
        struct epoll_event events[MAX_EPOLL_EVENTS];
        int size = epoll_wait(epoll_fd,events,MAX_EPOLL_EVENTS,-1);

        if(size<0)
        {
            LOG(ERROR,"epoll wait error");
            return;
        }
        else if(size == 0)
        {
            LOG(ERROR,"time out");
            continue; 
        }
        for(int i=0;i<size;i++)
        {
            //if (events[i].events != EPOLLIN)
			//{
			//	LOG(DEBUG, "event not equ EPOLLIN");
			//	continue;
			//}

            if (events[i].data.fd == listen_sockfd)
            {
                struct sockaddr_in client_addr;
                socklen_t len = sizeof(client_addr);

                int connect_fd = accept(listen_sockfd,(struct sockaddr*)&client_addr,&len);
                if(connect_fd<0)
                {
                    LOG(ERROR,"accept error");
                    continue;
                }

                int iRet = 0;
                //int iRet = SetNonBlock(connect_fd);
                //if(iRet != SUCCESS)
                //{
                   // LOG(ERROR,"Set nonblock error");
                    //continue;
                //}
                int master = -1;
                Task t;
                t.SetTask(connect_fd,master,PseudoTerminal::handler);
                pool.PushTask(t);
                
                while(master == -1)
                {
                }
                //set client fd event to epoll
                struct SockAndMaster S;
                S.sock = connect_fd;
                S.master = master;
                S.SorM = 1;
                struct epoll_event ev_sock;
                ev_sock.events = EPOLLIN;
                ev_sock.data.ptr = (void*)&S;
                iRet = epoll_ctl(epoll_fd,EPOLL_CTL_ADD,connect_fd,&ev_sock);
                if(iRet<0)
                {
                    LOG(ERROR,"epoll ctl add connect fd error");
                    continue;
                }
                
                //set master fd to epoll
                struct SockAndMaster M;
                M.sock = connect_fd;
                M.master = master;
                M.SorM = 2;
                struct epoll_event ev_master;
                ev_master.events = EPOLLIN;
                ev_master.data.ptr = (void*)&M;
                iRet = epoll_ctl(epoll_fd,EPOLL_CTL_ADD,master,&ev_master);
                if(iRet<0)
                {
                    LOG(ERROR,"epoll ctl add master fd error");
                    perror(":");
                    continue;
                }
                
                LOG(INFO,"a new connection created");
            }
            else if(events[i].events == EPOLLIN)
            {
                sleep(1);
                struct SockAndMaster* sam = (struct SockAndMaster*)(events[i].data.ptr);
                if(sam->SorM == 2)//master ready
                {
                    //Task t;
                    //t.SetTask(sam->master,sam->sock,PseudoTerminal::Communication);
                    char buff[MAX_BUFF_SIZE];
                    bzero(buff,MAX_BUFF_SIZE);

                    int read_size = read(sam->master,buff,MAX_BUFF_SIZE);
                    int write_size = write(sam->sock,buff,MAX_BUFF_SIZE);

                }
                else if(sam->SorM == 1)//client ready
                {
                    //Task t;
                   //t.SetTask(sam->sock,sam->master,PseudoTerminal::Communication);
                   char buff[MAX_BUFF_SIZE];
                    bzero(buff,MAX_BUFF_SIZE);

                    int read_size = read(sam->sock,buff,MAX_BUFF_SIZE);
                    int write_size = write(sam->master,buff,MAX_BUFF_SIZE);
                }
                else
                {
                    LOG(ERROR,"fd error,not client or master");
                    continue;
                }
            }
            else if(events[i].events == EPOLLOUT)
            {

            }
            
        }
    }while (true);  
}