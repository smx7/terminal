#include"threadpool.h"

void Task::SetTask(int _sock,int& _master,handler_t _handler)
{
    sock = _sock;
    handler = _handler;
    master = &_master;
}

void Task::Run()
{
    handler(sock,master);
}

ThreadPool::ThreadPool()
{
    max_thread_num = MAX_THREAD_NUM;
    thread_total_num = 0;
    thread_idle_num = 0;
    wait_seconds = MAX_WAIT_TIME;
    is_quit = false;
}

void ThreadPool::PushTask(Task& _t)
{
    mc.lock();

    if(is_quit)
    {
        mc.unlock();
        return;
    }

    task_queue.push(_t);
    LOG(DEBUG,"push task");

    mc.signal();
    mc.unlock();
}

void ThreadPool::PopTask(Task& _t)
{
    _t.sock = task_queue.front().sock;
    _t.master = task_queue.front().master;
    _t.handler = task_queue.front().handler;
    //_t = task_queue.front();
    task_queue.pop();
    LOG(DEBUG,"pop task");
}

void* ThreadPool::ThreadRoutine(void* arg)
{
    ThreadPool* tp = (ThreadPool*)arg;

    pthread_detach(pthread_self());

    while(true)
    {
        tp->mc.lock();
        bool timeout = false;

        ++(tp->thread_idle_num);

        while(tp->task_queue.empty()&&tp->is_quit==false)
        {
            std::cout<<"thread is waiting,thread id is: "<<pthread_self()<<std::endl;

            if(0!=tp->mc.timedwait(tp->wait_seconds))
            {
                LOG(DEBUG,"time out");
                timeout = true;
                break;
            }
        }

        --(tp->thread_idle_num);

        if(timeout == true&&tp->task_queue.empty())
        {
            --(tp->thread_total_num);
            tp->mc.unlock();
            break;
        }


        Task t;
        tp->PopTask(t);

        tp->mc.unlock();
        LOG(INFO,"task has been token");

        t.Run();
    }

    std::cout<<"thread is exited,thread id is: "<<pthread_self()<<std::endl;
    pthread_exit((void*)0);

}

void ThreadPool::InitThreadPool()
{
    for(int i=0;i<THREAD_INIT_NUM;i++)
    {
        pthread_t tid;
        pthread_create(&tid,NULL,ThreadRoutine,this);
    }
}