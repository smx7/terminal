#ifndef SERVER_H_
#define SERVER_H_

#include<iostream>
#include<pthread.h>
#include<unistd.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<sys/epoll.h>
#include<stdlib.h>
#include<fcntl.h>
#include<errno.h>
#include<map>
#include<sys/wait.h>
#include"threadpool.h"
#include"log.h"
#include"handler.h"

#define MAX_LISTEN_FD 1024
#define MAX_EPOLL_CREATE_FD 1024
#define MAX_EPOLL_EVENTS 1024
#define MAX_BUFF_SIZE 1024

struct SockAndMaster{
    int sock;
    int master;
    int SorM;
};
class TerminalServer{
    private:
        int listen_sockfd;
        int port;
        int epoll_fd;
        ThreadPool pool;
    public:
        TerminalServer(int _port)
            :listen_sockfd(-1),port(_port),epoll_fd(-1)
        {}
        
        int SetNonBlock(int fd);
        int InitServer();
        void StartServer();

};

#endif