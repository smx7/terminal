#ifndef LOG_H_
#define LOG_H_
#include<sys/time.h>
#include<string.h>
#include<stdlib.h>
#include<string>
#include<iostream>


#define INFO 1
#define DEBUG 2
#define ERROR 3

#define SUCCESS 0
#define FAILED -1

uint64_t GetTimeStamp();

std::string GetLogLevel (int level);

std::string GetTime();

void Log(int level,std::string message,std::string file,int line);

#define LOG(level,message) Log(level,message,__FILE__,__LINE__)

#endif
