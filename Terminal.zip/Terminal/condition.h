#ifndef CONDITION_H_
#define CONDITION_H_

#include<pthread.h>
#include<time.h>
#include"log.h"

class Condition
{
    public:

        Condition();
        ~Condition();
        
        int lock();
        int unlock();

        int signal();
        int boardcast();
        int wait();
        int timedwait(int seconds);

    private:
        pthread_mutex_t mutex;
        pthread_cond_t cond;
};
#endif