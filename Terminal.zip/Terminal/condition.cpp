#include"condition.h"

Condition::Condition()
{
    pthread_mutex_init(&mutex,NULL);
    pthread_cond_init(&cond,NULL);
}

Condition::~Condition()
{
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);
}

int Condition::lock()
{
    return pthread_mutex_lock(&mutex);
}

int Condition::unlock()
{
    return pthread_mutex_unlock(&mutex);
}

int Condition::signal()
{
    return pthread_cond_signal(&cond);
}

int Condition::boardcast()
{
    return pthread_cond_broadcast(&cond);
}

int Condition::wait()
{
    return pthread_cond_wait(&cond,&mutex);
}

int Condition::timedwait(int seconds)
{
     struct timespec abstime;
     clock_gettime(CLOCK_REALTIME, &abstime);
     abstime.tv_sec += seconds;
     return pthread_cond_timedwait(&cond,&mutex,&abstime);
}