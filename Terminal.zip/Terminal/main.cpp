#include"server.h"

static void usage(std::string proc)
{
    std::cout<<"usage: "<<proc<<" port"<<std::endl;
}

int main(int argc,char* argv[])
{
    if(argc != 2)
    {
        usage(argv[0]);
        return -1;
    }

    TerminalServer server = TerminalServer(atoi(argv[1]));
    server.InitServer();
    server.StartServer();

    return 0;

    
}