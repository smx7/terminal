#include"handler.h"

int PseudoTerminal::handler(int _sock,int* master)
{
    LOG(DEBUG,"handler");
    int _master = -1;
    int slave = -1;

    if(signal(SIGCHLD,WaitForChild) == SIG_ERR)
    {
        LOG(ERROR,"signal error");
    }

    _master = open("/dev/ptmx", O_RDWR | O_NOCTTY);
    if(_master == -1)
    {
        return -1;
    }

    if(grantpt(_master) == -1)
    {
        return -1;
    }

    if(unlockpt(_master) == -1)
    {
        return -1;
    }

    char* slaveName = ptsname(_master);
    if(slaveName == NULL)
    {
        return -1;
    }

    slave = open(slaveName, O_RDWR | O_NOCTTY);
    if(slave == -1)
    {
        return -1;
    }
    *master = _master;
    //if(OpenPseudoTerminal(&master,slave)<0)
    //{
        //LOG(ERROR,"open pseudo terminal error");
    //}

    int pid = fork();
    if(pid < 0)
    {
        close(_master);
        close(slave);
        LOG(ERROR,"fork error");
    }
    else if(pid == 0)
    {
        close(_master);
        setsid();
        dup2(slave,0);
        dup2(slave,1);
        dup2(slave,2);
        execlp("sh",NULL);
    }
    else
    {
        LOG(INFO,"father process");
    }
    
}

int PseudoTerminal::OpenPseudoTerminal(int* master,int& slave)
{
    int _master = open("/dev/ptmx", O_RDWR | O_NOCTTY);
    if(_master == -1)
    {
        return -1;
    }

    if(grantpt(_master) == -1)
    {
        return -1;
    }

    if(unlockpt(_master) == -1)
    {
        return -1;
    }

    char* slaveName = ptsname(_master);
    if(slaveName == NULL)
    {
        return -1;
    }

    slave = open(slaveName, O_RDWR | O_NOCTTY);
    if(slave == -1)
    {
        return -1;
    }
    *master = _master;
    return 0;
}

void PseudoTerminal::WaitForChild(int signo)
{
    int status;
    while(waitpid(-1, &status, WNOHANG) > 0);
    exit(1);
}

int PseudoTerminal::Communication(int inFd,int* outFd)
{
    char buff[MAX_BUFF_SIZE];
    bzero(buff,MAX_BUFF_SIZE);

    int read_size = read(inFd,buff,MAX_BUFF_SIZE);
    if(read_size < 0)
    {
        return -1;
    }

    int write_size = write(*outFd,buff,MAX_BUFF_SIZE);
    if(write_size <= 0)
    {
        return -1;
    }

    return 0;
}