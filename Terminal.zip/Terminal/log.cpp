#include"log.h"

uint64_t GetTimeStamp()
{
    struct timeval time;
    gettimeofday(&time, NULL);
    return time.tv_sec;
}

std::string GetLogLevel (int level)
{
    switch(level)
    {
        case 1:
            return "INFO";
        case 2:
            return "DEBUG";
        case 3:
            return "ERROR";
    }
}

std::string GetTime()
{
    struct timeval tv;
    time_t time;
    char str_t[26] = {0};

    gettimeofday (&tv, NULL);

    time = tv.tv_sec;

    struct tm* p_time = localtime(&time);
    strftime(str_t, 26, "%Y-%m-%d %H:%M:%S", p_time);
    return str_t;
}

void Log(int level,std::string message,std::string file,int line)
{
            std::cout<<"[ "<<GetTime()<<" ]"<<" [ "<<GetTimeStamp()<<" ]"<<" [ "<<GetLogLevel(level)<<" ]"<<" [ "<<file<<" : "<<line<<" ] "<<message<<std::endl;
}